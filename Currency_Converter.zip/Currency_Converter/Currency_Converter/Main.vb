﻿Public Class Main



    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click

        Dim amount As String
        Dim total As String

        amount = txtAMount.Text
        total = lblOutput.Text

        If cmbTO.SelectedIndex = 1 Then
            lblOutput.Text = "€".PadRight(2) & amount * 0.052

        ElseIf cmbTO.SelectedIndex = 2 Then
            lblOutput.Text = "₤".PadRight(2) & amount * 0.046

        ElseIf cmbTO.SelectedIndex = 3 Then
            lblOutput.Text = "$".PadRight(2) & amount * 0.056

        ElseIf cmbTO.SelectedIndex = 4 Then
            lblOutput.Text = "HK$".PadRight(4) & amount * 0.44

        End If

        Label5.Show()
        lblOutput.Visible = True
        btnClear.Show()
    End Sub

    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        cmbTO.SelectedIndex = 0
        Label5.Hide()
        lblOutput.Visible = False
        btnClear.Hide()

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lblOutput.Text = String.Empty
        txtAMount.Text = "R"
        txtAMount.Clear()
        cmbTO.SelectedIndex = 0
        Label5.Hide()
        lblOutput.Visible = False
        btnClear.Hide()
    End Sub
End Class