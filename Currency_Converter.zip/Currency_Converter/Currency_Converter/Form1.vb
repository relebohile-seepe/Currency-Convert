﻿Public Class Form1

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        GunaProgressBar1.Increment(1)
        If GunaProgressBar1.Value = 100 Then
            Main.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub GunaProgressBar1_Click(sender As Object, e As EventArgs) Handles GunaProgressBar1.Click

    End Sub
End Class
